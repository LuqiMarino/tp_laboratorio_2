﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int legajo;

        public int Legajo
        {
            get { return this.legajo; }
            set { this.legajo = value; }
        }

        public Universitario() : base()
        { }

        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(nombre, apellido, dni, nacionalidad)
        {
            this.legajo = legajo;
        }

        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine($"Legajo: {this.legajo}");
            return sb.ToString();
        }

        protected abstract string ParticiparEnClase();

        public static bool operator ==(Universitario u1, Universitario u2)
        {
            if (!(u1 is null) && !(u2 is null))
            {
                if ((u1.Dni == u2.Dni || u1.legajo == u2.legajo) && u1.GetType() == u2.GetType())
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Universitario u1, Universitario u2)
        {
            return !(u1 == u2);
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (!(obj is null) && (obj is Universitario))
            {
                if (this == (Universitario)obj)
                    retorno = true;
            }
            return retorno;
        }
    }
}
