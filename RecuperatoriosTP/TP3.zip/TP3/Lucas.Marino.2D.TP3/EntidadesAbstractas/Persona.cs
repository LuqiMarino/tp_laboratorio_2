﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino, Extranjero
        }

        #region Campos
        private string nombre;
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        #endregion

        #region Propiedades
        public string Nombre
        {
            get { return this.nombre; }
            set { this.nombre = this.ValidarNombreApellido(value); }
        }

        public string Apellido
        {
            get { return this.apellido; }
            set { this.apellido = value; }
        }

        public int Dni
        {
            get { return this.dni; }
            set
            { this.dni = this.ValidarDni(this.nacionalidad, value); }

        }
        public string StringToDNI
        {
            set { this.dni = this.ValidarDni(this.nacionalidad, value); }
        }

        public ENacionalidad Nacionalidad
        {
            get { return this.nacionalidad; }
            set { this.nacionalidad = value; }
        }
        #endregion

        #region Constructores
        public Persona()
        { }

        public Persona(string nombre, string apellido, ENacionalidad nacionalidad) : this()
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }

        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.Dni = dni;
        }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat($"Nombre: {this.nombre}\nApellido: {this.apellido}\nDNI: {this.dni}");
            return sb.ToString();
        }

        private int ValidarDni(ENacionalidad nacionalidad, int auxdni)
        {            
            return this.ValidarDni(nacionalidad, auxdni.ToString());
        }

        private int ValidarDni(ENacionalidad nacionalidad, string auxdni)
        {            
            int retorno = 0;
            switch (nacionalidad)
            {
                case ENacionalidad.Argentino:
                    if (int.TryParse(auxdni, out retorno))
                    {
                        if (retorno < 1 || retorno > 89999999)
                        {
                            throw new NacionalidadInvalidaException("El DNI no es demasiado corto o largo para la nacionalidad");
                        }
                    }
                    else
                        throw new DniInvalidoException("El DNI de nacionalidad Argentino es incorrecto");
                    break;
                case ENacionalidad.Extranjero:
                    if (int.TryParse(auxdni, out retorno))
                    {
                        if (retorno < 89999999)
                        {
                            throw new NacionalidadInvalidaException("La nacionalidad no se coincide con el numero de dni");
                        }
                    }
                    else
                        throw new DniInvalidoException("El DNI de nacionalidad Extranjero es incorrecto");
                    break;
                default:
                    break;
            }
            return retorno;
        }

        private string ValidarNombreApellido(string auxnombre)
        {
            string retorno = null;
            bool aux = true;
            if (!(auxnombre is null))
            {
                foreach (char item in auxnombre)
                {
                    if (!char.IsLetter(item))
                    {
                        aux = false;
                        break;
                    }
                }
                if (aux)
                    retorno = auxnombre;
            }
            return retorno;
        }
        #endregion
    }
}
