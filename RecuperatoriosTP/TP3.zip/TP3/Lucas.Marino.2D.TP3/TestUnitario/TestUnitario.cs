﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;
using EntidadesAbstractas;
using Excepciones;

namespace TestUnitario
{
    [TestClass]
    public class TestUnitario
    {
        [TestMethod]
        public void TestValidaDNI()
        {
            int dni = 39465462;
            Alumno aux = new Alumno(1, "Lucas", "Marino", dni.ToString(), ENacionalidad.Argentino, Universidad.EClases.Laboratorio);

            int resultado = aux.Dni;

            Assert.AreEqual(dni, resultado);
        }

        [TestMethod]
        public void TestNuevoAlumno()
        {
            Alumno aux = new Alumno(1, "Lucas", "Marino", "39465462", ENacionalidad.Argentino, Universidad.EClases.Laboratorio);

            Assert.IsNotNull(aux.Nombre);
            Assert.IsNotNull(aux.Dni);
            Assert.IsNotNull(aux.Apellido);
            Assert.IsNotNull(aux.Nacionalidad);
        }

        [TestMethod]
        public void TestSinProfesorException()
        {
            Universidad aux = new Universidad();

            try
            {
                aux += Universidad.EClases.Laboratorio;
            }

            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(SinProfesorException));
            }
        }

        [TestMethod]
        [ExpectedException(typeof(Excepciones.DniInvalidoException))]
        public void TestAlumnoRepetidoException()
        {
            Alumno aux = new Alumno(1, "Lucas", "Marino", null, ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
        }
    }
}
