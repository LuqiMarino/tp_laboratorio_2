﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException : Exception
    {
        #region Campos

        private static string msj = "Dni invalido!";

        #endregion

        #region Metodos

        public DniInvalidoException() : this(msj)
        { }

        public DniInvalidoException(Exception e) : this(msj, e)
        { }

        public DniInvalidoException(string mensaje) : base(msj)
        { }

        public DniInvalidoException(string mensaje, Exception e) : base(msj, e)
        { }
        #endregion
    }
}
