﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Archivos
{
    interface IArchivo<T>
    {
        bool Guardar(string arch, T datos);
        bool Leer(string arch, out T datos);
    }
}
