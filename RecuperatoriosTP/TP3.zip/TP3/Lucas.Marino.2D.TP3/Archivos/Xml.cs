﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        public bool Guardar(string archivo, T datos)
        {
            bool retorno = true;
            XmlSerializer xmlSer = new XmlSerializer(typeof(T));
            XmlTextWriter xmlWriter = null;
            try
            {
                xmlWriter = new XmlTextWriter(archivo, null);
                xmlSer.Serialize(xmlWriter, datos);
            }
            catch (Exception)
            {
                retorno = false;
            }
            finally
            {
                xmlWriter.Close();
            }
            return retorno;
        }

        public bool Leer(string archivo, out T datos)
        {
            XmlSerializer xmlSer = new XmlSerializer(typeof(T));
            XmlTextReader xmlReader = null;
            bool retorno = true;
            try
            {
                xmlReader = new XmlTextReader(archivo);
                datos = (T)xmlSer.Deserialize(xmlReader);
            }
            catch (Exception)
            {
                datos = default(T);
                retorno = false;
            }
            finally
            {
                xmlReader.Close();
            }
            return retorno;
        }
    }
}
