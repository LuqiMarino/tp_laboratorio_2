﻿using System;
using System.IO;


namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        #region Metodos

        public bool Guardar(string archivo, string datos)
        {
            bool retorno = true;
            StreamWriter file = null;
            try
            {
                file = new StreamWriter(archivo, false);
                file.Write(datos);
            }
            catch (Exception)
            {
                retorno = false;  
            }
            finally
            {
                file.Close();
            }
            return retorno;
        }

        public bool Leer(string archivo, out string datos)
        {
            StreamReader file = null;
            bool retorno = true; 
            try
            {
                file = new StreamReader(archivo);
                datos = file.ReadToEnd();
            }
            catch (Exception)
            {
                datos = null;
                retorno = false;
            }
            finally
            {
                file.Close();
            }
            return retorno;
        }
        #endregion
    }
}
