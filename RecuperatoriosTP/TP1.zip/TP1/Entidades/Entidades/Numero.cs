﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        #region Campos
        private double numero;
        #endregion

        #region Constructores
        public Numero()
        {
            this.numero = 0;
        }

        public Numero(double numero)
        {
            this.numero = numero;
        }

        public Numero(string numero)
        {
            this.numero = ValidarNumero(numero);
        }
        #endregion

        #region Propiedades
        public string SetNumero
        {
            set
            {
                this.numero = ValidarNumero(value);
            }
        }
        #endregion

        #region Metodos
        private static double ValidarNumero(string strNumero)
        {
            double retorno;
            bool isNum = double.TryParse(strNumero, out retorno);
            if (isNum)
                return retorno;
            else
                return 0;
        }

        public string BinarioADecimal(string binario)
        {
            double retorno = 0;
            bool flag = false;
            for (int i = 1; i <= binario.Length; i++)
            {
                if (binario[i - 1] == '0' || binario[i - 1] == '1')
                    retorno += int.Parse(binario[i - 1].ToString()) * (double)Math.Pow(2, binario.Length - i);
                else
                    flag = true;
            }
            if (flag)
                return "Valor invalido";
            else
                return retorno.ToString();             
        }

        public string DecimalABinario(double numero)
        {
            string strBinario = "";
            while (numero >= 1)
            {
                strBinario = Math.Floor(numero % 2).ToString() + strBinario;
                numero /= 2;
            }
            return strBinario;
        }

        public string DecimalABinario(string numero)
        {
            SetNumero = numero;
            return this.numero <= 0 ? "Valor Invalido" : DecimalABinario(this.numero);
        }

        #endregion

        #region Sobrecarga
        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }

        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }

        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }

        public static double operator /(Numero n1, Numero n2)
        {
            double retorno = 0;
            if (n2.numero != 0)
                retorno = n1.numero / n2.numero;
            return retorno;
        }
        #endregion
    }
}
