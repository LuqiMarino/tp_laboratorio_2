﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        #region Metodos

        private static string ValidarOperador(string operador)
        {
            if (operador != "-" && operador != "*" && operador != "/")
            {
                operador = "+";
            }
            return operador;
        }

        public double Operar(Numero num1, Numero num2, string operador)
        {
            double retorno = 0;
            operador = ValidarOperador(operador);
            switch (operador)
            {
                case "+":
                    retorno = num1 + num2;
                    break;
                case "-":
                    retorno = num1 - num2;
                    break;
                case "*":
                    retorno = num1 * num2;
                    break;
                case "/":
                    retorno = num1 / num2;
                    if (retorno == 0)
                        retorno = double.MinValue;
                    break;
            }
            return retorno;
        }
    }
    #endregion
}
