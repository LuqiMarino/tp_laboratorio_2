﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using FrmPpal;
using System.Collections.Generic;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ListaPaquetesInstanciada()
        {
            Correo c = new Correo();
            List<Paquete> lista = null;

            lista = c.Paquetes;
            Assert.IsNotNull(lista);
        }

        [TestMethod]
        [ExpectedException(typeof(TrackingIDRepetidoException))]
        public void MismoTrackingId()
        {
            Correo c = new Correo();
            Paquete p1 = new Paquete("Direccion 1", "012-345-6789");
            Paquete p2 = new Paquete("Direccion 2", "012-345-6789");
            
            c += p1;
            c += p2;            
        }
    }
}
