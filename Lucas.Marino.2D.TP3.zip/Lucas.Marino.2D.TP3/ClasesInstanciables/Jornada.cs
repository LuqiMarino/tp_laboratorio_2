﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Jornada
    {
        #region Campos
        private List<Alumno> alumnos;
        private Universidad.EClases clases;
        private Profesor instructor;
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }

        public Universidad.EClases Clases
        {
            get { return this.clases; }
            set { this.clases = value; }
        }

        public Profesor Instructor
        {
            get { return this.instructor; }
            set { this.instructor = value; }
        }
        #endregion

        #region Constructores
        private Jornada()
        {
            this.alumnos = new List<Alumno>();
        }

        public Jornada(Universidad.EClases clases, Profesor instructor) : this()
        {
            this.Clases = clases;
            this.Instructor = instructor;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat($"Clase de {this.Clases} por {this.Instructor.ToString()}\nAlumnos:");
            foreach (Alumno item in this.Alumnos)
            {
                sb.AppendLine(item.ToString());
            }
            sb.Append("\n\n");
            return sb.ToString();
        }

        public static string Leer()
        {
            Texto aux = new Texto();
            string datos = null;
            try
            {
                aux.Leer("Jornada.txt", out datos);
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }
            return datos;
        }
        
        public static bool Guardar(Jornada jornada)
        {
            if (!(jornada is null))
            {
                Texto texto = new Texto();
                try
                {
                    texto.Guardar("Jornada.txt", jornada.ToString());
                }
                catch (Exception e)
                {
                    throw new ArchivosException(e);
                }
            }
            return true; ;
        }

        public static bool operator ==(Jornada j, Alumno a)
        {
            if (!(j is null) && !(a is null))
            {
                foreach (Alumno item in j.Alumnos)
                {
                    if (item == a)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static Jornada operator +(Jornada j, Alumno a)
        {
            if (j != a)
                j.Alumnos.Add(a);
            return j;
        }
        #endregion
    }
}
