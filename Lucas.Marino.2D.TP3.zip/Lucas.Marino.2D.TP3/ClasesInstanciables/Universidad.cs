﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
    public class Universidad
    {
        public enum EClases
        {
            Programacion, Laboratorio, Legislacion, SPD
        }
        #region Campos
        private List<Jornada> jornada;
        private List<Profesor> profesores;
        private List<Alumno> alumnos;
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }

        public List<Profesor> Profesores
        {
            get { return this.profesores; }
            set { this.profesores = value; }
        }

        public List<Jornada> Jornadas
        {
            get { return this.jornada; }
            set { this.jornada = value; }
        }

        public Jornada this[int i]
        {
            get { return this.jornada[i]; }
            set { this.jornada[i] = value; }
        }
        #endregion

        #region Constructores
        public Universidad()
        {
            this.Alumnos = new List<Alumno>();
            this.Profesores = new List<Profesor>();
            this.Jornadas = new List<Jornada>();
        }
        #endregion

        #region Metodos
        private static string MostrarDatos(Universidad u)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Jornada:");
            foreach (Jornada item in u.Jornadas)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }

        public override string ToString()
        {
            return MostrarDatos(this);
        }

        public static bool operator ==(Universidad u, Alumno a)
        {
            if (!(u is null) && !(a is null))
            {
                foreach (Alumno item in u.Alumnos)
                {
                    if (item == a)
                        return true;
                }
            }
            return false;
        }

        public static bool operator !=(Universidad u, Alumno a)
        {
            return !(u == a);
        }

        public static Universidad operator +(Universidad u, Alumno a)
        {
            if (!(u is null) && !(a is null))
            {
                if (u != a)
                    u.Alumnos.Add(a);
                else
                    throw new AlumnoRepetidoException();
            }
            return u;
        }

        public static bool operator ==(Universidad u, Profesor p)
        {
            if (!(u is null) && !(p is null))
            {
                foreach (Profesor item in u.Profesores)
                {
                    if (item == p)
                        return true;
                }
            }
            return false;
        }

        public static bool operator !=(Universidad u, Profesor p)
        {
            return !(u == p);
        }

        public static Universidad operator +(Universidad u, Profesor p)
        {
            if (!(u is null) && !(p is null))
            {
                if (u != p)
                    u.Profesores.Add(p);
            }
            return u;
        }

        public static Profesor operator ==(Universidad u, EClases c)
        {
            if (!(u is null))
            {
                foreach (Profesor item in u.Profesores)
                {
                    if (item == c)
                        return item;
                }
            }
            throw new SinProfesorException();
        }

        public static Profesor operator !=(Universidad u, EClases c)
        {
            if (!(u is null))
            {
                foreach (Profesor item in u.Profesores)
                {
                    if (item != c)
                        return item;
                }
            }
            throw new SinProfesorException();
        }

        public static Universidad operator +(Universidad u, EClases c)
        {
            Profesor auxProf = null;
            Jornada auxJorn = null;

            if (!(u is null))
            {
                auxProf = (u == c);
                auxJorn = new Jornada(c, auxProf);
                foreach (Alumno item in u.alumnos)
                {
                    if (item == c)
                        auxJorn += item;
                }
                u.Jornadas.Add(auxJorn);
            }
            return u;
        }

        public static bool Guardar(Universidad u)
        {
            Xml<Universidad> auxXml = new Xml<Universidad>();
            try
            {
                auxXml.Guardar("Universidad.xml", u);
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }
            return true;
        }

        public static Universidad Leer()
        {
            Universidad retorno = null;
            Xml<Universidad> auxXml = new Xml<Universidad>();
            try
            {
                auxXml.Leer("Universidad.xml", out retorno);
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }
            return retorno;
        }
        #endregion
    }
}
