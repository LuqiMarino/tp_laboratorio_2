﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino, Extranjero
        }

        #region Campos
        private string nombre;
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        #endregion

        #region Propiedades
        public string Nombre
        {
            get { return this.nombre; }
            set
            {

            }
        }

        public string Apellido
        {
            get { return this.apellido; }
            set { this.apellido = value; }
        }

        public int Dni
        {
            get { return this.dni; }
            set
            {

            }

        }
        public string StringToDNI
        {
            set { }
        }

        public ENacionalidad Nacionalidad
        {
            get { return this.nacionalidad; }
            set { this.nacionalidad = value; }
        }
        #endregion

        #region Constructores
        public Persona()
        { }

        public Persona(string nombre, string apellido, ENacionalidad nacionalidad) : this()
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }

        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.Dni = dni;
        }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat($"Nombre: {this.nombre}\nApellido: {this.apellido}\nDNI: {this.dni}");
            return sb.ToString();
        }

        private int ValidarDni(ENacionalidad nacionalidad, int auxdni)
        {
            if (auxdni < 1 || auxdni > 99999999)
            {
                throw new DniInvalidoException("Dni fuera de rango.");
            }
            switch (nacionalidad)
            {
                case ENacionalidad.Argentino:
                    if (auxdni > 89999999)
                        throw new NacionalidadInvalidaException("La nacionalidad no coincide con el numero de DNI.");
                    break;
                case ENacionalidad.Extranjero:
                    if (auxdni <= 89999999)
                        throw new NacionalidadInvalidaException("La nacionalidad no coincide con el numero de DNI.");
                    break;
            }
            return auxdni;
        }

        private int ValidarDni(ENacionalidad nacionalidad, string auxdni)
        {
            int retorno = 0;
            bool aux = true;
            if (!(auxdni is null))
            {
                for (int i = 0; i < auxdni.Length; i++)
                {
                    if (auxdni[i] < '0' || auxdni[i] > '9')
                    {
                        aux = false;
                        break;
                    }
                }
                if (aux)
                {
                    Int32.TryParse(auxdni, out retorno);
                }
                else
                    throw new DniInvalidoException("El DNI tiene caracteres invalidos!");
            }
            return this.ValidarDni(nacionalidad, retorno);
        }

        private string ValidarNombreApellido(string auxnombre)
        {
            string retorno = null;
            bool aux = true;
            if (!(auxnombre is null))
            {
                foreach (char item in auxnombre)
                {
                    if (!char.IsLetter(item))
                    {
                        aux = false;
                        break;
                    }
                }
                if (aux)
                    retorno = auxnombre;
            }
            return retorno;
        }
        #endregion
    }
}
